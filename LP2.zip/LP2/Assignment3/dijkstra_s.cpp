#include<bits/stdc++.h>
using namespace std;

int main(){
    int n,m,source;
    cout<<"Enter total number of vertices and edges: ";
    cin>>n>>m;

    vector<pair<int,int>> g[n+1]; //to store graph
    int a,b,wt;
    for(int i=0;i<m;i++){
        cout<<"Enter edge between a and b, and corresponding weight of edge: ";
        cin>>a>>b>>wt;

        g[a].push_back(make_pair(b,wt));
        g[b].push_back(make_pair(a,wt));
    }

    cout<<"Enter source vertex: ";
    cin>>source;

    vector<int> distTo(n+1,INT_MAX);
    distTo[source]=0;

    priority_queue< pair<int,int> , vector<pair<int,int>>, greater<pair<int,int>> > pq; //min-heap
    pq.push(make_pair(0,source));

    while(!pq.empty()){
        int prevDist=pq.top().first;
        int prev=pq.top().second;
        pq.pop();

        for(auto it: g[prev]){
            int nxt=it.first;
            int nxtDist=it.second;
            if(distTo[nxt]>distTo[prev]+nxtDist){
                distTo[nxt]=distTo[prev]+nxtDist;
                pq.push(make_pair(distTo[nxt],nxt));
            }
        }
    }

    cout<<"Distance from "<< source<< " are: ";
    for(int i=1;i<=n;i++){
        cout<<distTo[i]<<" ";
    }
    cout<<"\n";
    return 0;
}