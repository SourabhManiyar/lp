#include<bits/stdc++.h>
using namespace std;

#define v 5

void printMST(int mst[v],int graph[v][v]){
    cout<<"Edge \tWeight\n";
	for (int i = 1; i < v; i++)
		cout<<mst[i]<<" - "<<i<<" \t"<<graph[i][mst[i]]<<" \n";
}

//to get index of minimum weight edge
int minKey(int key[v],bool mstSet[v]){
    int min=INT_MAX,min_index;
    for(int i=0;i<v;i++){
        if(mstSet[i]==false && key[i]<min){
            min=key[i];
            min_index=i;
        }
    }
    return min_index;
}

void findMST(int graph[v][v]){
    int mst[v]; //to store constructed mst
    int key[v]; //used to pick minimum weight edge cut
    bool mstSet[v]; //used to keep track of which vertices included in MST

    //Initialise all keys to infinite
    for(int i=0;i<v;i++){
        key[i]=INT_MAX;
        mstSet[i]=false;
    }

    key[0]=0; //first vertex is always picked
    mst[0]=-1; //to made root node

    //to get all edges i.e v-1
    for(int i=0;i<v-1;i++){

        int u=minKey(key,mstSet);

        mstSet[u]=true;

        for(int j=0;j<v;j++){
            if(graph[u][j] && mstSet[j]==false && graph[u][j]<key[j]){
                mst[j]=u;
                key[j]=graph[u][j];
            }
        }
    }

    printMST(mst,graph);
}

int main(){
    int graph[v][v]={
        { 0, 2, 0, 6, 0 },
        { 2, 0, 3, 8, 5 },
        { 0, 3, 0, 0, 7 },
        { 6, 8, 0, 0, 9 },
        { 0, 5, 7, 9, 0 }
    };

    findMST(graph);

    return 0;
}