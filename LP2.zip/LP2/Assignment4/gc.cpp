#include<bits/stdc++.h>
using namespace std;

int main(){
  int m,n;  //m=vertices, n=edges
  cout<<"Enter total number of vertices and edges: ";
  cin>>m>>n;

  vector<vector<int>> adj(m+1); // to store the graph--> adjacancy list

  for(int i=0;i<n;i++){
    int u,v;
    cout<<"Enter edge between two vertices: ";
    cin>>u>>v;
    adj[u].push_back(v);
    adj[v].push_back(u);
  }

  vector<int> color(m+1,0);   //to store color of graph
  vector<bool> visited(m+1,false);  //to store if vertex is visited or not

  color[1]=1;
  visited[1]=true;

  queue<int> q;  //used to traverse graph in BFS way
  q.push(1);

  while(!q.empty()){
    int node=q.front();
    q.pop();

    set<int> s;  //to store the colors of neighbour nodes
    for(auto neigh: adj[node]){
      if(color[neigh]>0){
        s.insert(color[neigh]);
      }
      if(!visited[neigh]){
        q.push(neigh);
        visited[neigh]=true;
      }
    }

    if(s.empty()) continue;

    int paint=-1;
    vector<int> v(s.begin(),s.end());

    for(int i=0;i<v.size();i++){
      if(v[i]!=(i+1)){
        paint=i+1;
        break;
      }
    }

    if(paint==-1){
      paint=v[v.size()-1]+1;
    }

    color[node]=paint;

    
  }
  cout<<"The colour of graph is: ";
  for(int i=1;i<m+1;i++){
    cout<<color[i]<<" ";
  }
  cout<<endl;
  return 0;
}