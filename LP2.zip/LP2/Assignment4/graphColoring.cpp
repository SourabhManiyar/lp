#include<bits/stdc++.h>

using namespace std;

#define ll long long

vector<vector<ll>> adj(200001);

int main()
{
    ll n,m;
    cin>>n>>m; //here n is the number of nodes in the graph and m is the edges fo the graph

    adj.resize(n+1);

    for(ll i=0;i<=n;i++)
    {
        adj[i].clear();
    }

    for(ll i=0;i<m;i++)
    {
        ll u,v;
        cin>>u>>v;

        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    vector<ll> color(n+1,0);

    queue<ll> qu;
    qu.push(1);
    bool vis[n+1]={0};
    vis[1]=true;
    color[1]=1;

    while(!qu.empty())
    {
        ll node=qu.front();
        qu.pop();

        set<ll> st;
        for(auto neigh:adj[node])
        {
            if(color[neigh]>0)
            st.insert(color[neigh]);
            if(!vis[neigh])
            {
                qu.push(neigh);
                vis[neigh]=true;
            }
        }
        if(st.empty())
        continue;

        vector<ll> vec(st.begin(),st.end());
        ll topaint=-1;
        for(ll i=0;i<vec.size();i++)
        {
            if(vec[i]!=(i+1))
            {
                topaint=i+1;
            break;
            }
        }

        if(topaint==-1)
        {
            topaint=vec[vec.size()-1]+1;
        }
        color[node]=topaint;
    }

    cout<<"The color of the graph is : ";
    for(ll i=1;i<=n;i++)
    {
        cout<<color[i]<<" ";
    }
    cout<<endl;
    
}