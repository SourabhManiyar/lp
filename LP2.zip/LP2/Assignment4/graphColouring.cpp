#include<bits/stdc++.h>
using namespace std;

int main(){
    int n,m;
    cout<<"Enter total number of vertices and edges: ";
    cin>>n>>m;
    vector<vector<int>> adj(n+1); //to store graph
    for(int i=0;i<m;i++){
        int u,v;
        cout<<"Enter edge between two vertices: ";
        cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    int color[n+1]={0};
    bool visit[n+1]={0};
    color[1]=1;
    visit[1]=true;
    queue<int> q;
    q.push(1);

    while(!q.empty()){
        int node=q.front();
        q.pop();

        set<int> s;
        for(int neigh: adj[node]){
            if(color[neigh]>0){
                s.insert(color[neigh]);
            }
            if(!visit[neigh]){
                q.push(neigh);
                visit[neigh]=true;
            }
        }
        if(s.empty()) continue;

        vector<int> v(s.begin(),s.end());
        int paint=-1;
        for(int i=0;i<v.size();i++){
            if(v[i]!=(i+1)){
                paint=i+1;
                break;
            }
        }
        if(paint==-1){
            paint=v[v.size()-1]+1;
        }
        color[node]=paint;
    }
    cout<<"The color of the graph is : ";
    for(int i=1;i<=n;i++)
    {
        cout<<color[i]<<" ";
    }
    cout<<endl;
    return 0;
}